<x-layouts.layout>
    <h1>Estoy en about</h1>
    <a href="main">Volver al main</a>
</x-layouts.layout>
