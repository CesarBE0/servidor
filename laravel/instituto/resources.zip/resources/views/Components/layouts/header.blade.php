<header class="h-20 bg-header flex justify-between items-center px-8 shadow-md">
    {{-- Contenedor del Logo --}}
    <div class="flex items-center h-full">
        <img src="{{ asset("img/logo.png") }}" alt="logo" class="h-14 w-auto object-contain">
    </div>

    {{-- Título Central --}}
    <h1 class="text-3xl font-bold text-blue-500 tracking-tight">
        GESTIÓN DEL INSTITUTO
    </h1>

    {{-- Lado Derecho: Usuario o Login --}}
    <div class="flex items-center gap-4">
        @auth
            <div class="flex items-center gap-2 bg-white/50 px-3 py-1 rounded-full border border-blue-200">
                <span class="text-sm text-gray-600">Hola,</span>
                <span class="font-semibold text-blue-700">{{ auth()->user()->name }}</span>
            </div>
        @endauth

        @guest
            <div class="flex gap-3">
                <a href="" class="bg-blue-600 hover:bg-blue-700 text-black font-semibold py-2 px-4 rounded-lg transition duration-300 ease-in-out shadow-md">Login</a>
                <a href="" class="bg-blue-600 hover:bg-blue-700 text-black font-semibold py-2 px-4 rounded-lg transition duration-300 ease-in-out shadow-md">
                    Register
                </a>
            </div>
        @endguest
    </div>
</header>
