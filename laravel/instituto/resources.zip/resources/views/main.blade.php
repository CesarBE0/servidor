
<x-layouts.layout>
    <h1>Estoy en main</h1>
</x-layouts.layout>
